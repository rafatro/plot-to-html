# plot2html
Create a static .html file with charts using Google Charts API


This is just the begining
